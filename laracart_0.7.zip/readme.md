## Laracart The Laravel Online Store
Laravel online store using laravel 5.6, Materialize-css 1.0.0rc-2, JQuery, Material icons, google fonts and etc.


### Cart
- This Software is Using [LaravelShoppingCart](https://github.com/Crinsane/LaravelShoppingcart) which is a package that gives you all the cart features.

### Publish resources for Ckeditor
```bash
php artisan vendor:publish --tag=ckeditor
```