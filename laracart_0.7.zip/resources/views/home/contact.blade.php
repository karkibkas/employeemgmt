@extends('layouts.app')

@section('content')
<h3 class="center grey-text text-darken-1">Contact Page</h3>
@endsection