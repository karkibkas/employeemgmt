@extends('layouts.app')

@section('content')
<h3 class="center grey-text text-darken-1">Index Page</h3>
@endsection