@extends('layouts.app')
@section('content')
Admin Dashboard
@endsection