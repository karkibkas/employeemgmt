<?php $__env->startSection('content'); ?>
<div class="container">
    <br><br>
    <div class="card-panel">
        <h4 class="center">Enter Your Email</h4>
        <form method="post" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="input-field">
                <input type="text" name="email" id="email">
                <label for="email">Email</label>
                <?php if($errors->has('email')): ?>
                    <span class="helper-text red-text"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn waves-effect waves-light">Send Link</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>