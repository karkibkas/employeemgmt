<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="card-panel">
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($category->id); ?></td>
                                <td><?php echo e($category->title); ?></td>
                                <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                                <?php if($category->updated_at): ?>
                                    <td><?php echo e($category->updated_at->diffForHumans()); ?></td>
                                <?php else: ?>
                                    <td>Not updated</td>
                                <?php endif; ?>
                                <td>
                                    <a href="<?php echo e(route('admin.categories.edit',$category->id)); ?>" class="btn-floating btn-small waves-effect orange waves-light">
                                        <i class="material-icons">mode_edit</i>
                                    </a>
                                    <a href="#delete-modal-<?php echo e($category->id); ?>" class="btn-floating btn-small waves-effect red modal-trigger waves-light">
                                        <i class="material-icons">delete</i>
                                    </a>
                                </td>
                                <?php $__env->startComponent('components.confirm',[
                                    'id' => 'delete-form-'.$category->id,
                                    'modal' => 'delete-modal-'.$category->id,
                                    'title' => 'Category'
                                ]); ?>
                                <?php echo $__env->renderComponent(); ?>
                                <form action="<?php echo e(route('admin.categories.destroy',$category->id)); ?>" method="post" class="hide" id="delete-form-<?php echo e($category->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="fixed-action-btn">
                <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn-floating btn-large waves-effect waves-light red">
                    <i class="large material-icons">add</i>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>