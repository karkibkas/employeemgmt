<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card-panel">
                    <h4 class="center grey-text text-darken-1">My Order History</h4>
                    <br>
                    <table class="responsive-table centered grey-text text-darken-3">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Customer Name</th>
                                <th>No of Products</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Created at</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e(Auth::user()->name); ?></td>
                                    <td>
                                        fixing it
                                        
                                    </td>
                                    <td class="val">$<?php echo e(number_format($order->total,2)); ?> /- </td>
                                    <td><?php echo e((!$order->payment->failed) ? 'paid' : 'failed'); ?></td>
                                    <td><?php echo e($order->created_at->diffForHumans()); ?></td>
                                    <td>
                                        <a href="#" class="btn-floating btn-small darken-3 tooltipped" data-position="left" data-tooltip="View Details">
                                            <i class="material-icons">visibility</i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br><br>
                    <div class="center-align">
                        <?php echo e($orders->links('vendor.pagination.default',['items' => $orders])); ?>

                    </div>
                    <br><br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>