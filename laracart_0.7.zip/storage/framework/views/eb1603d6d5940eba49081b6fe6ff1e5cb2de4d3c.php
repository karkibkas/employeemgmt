<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col s12 m8 offset-m2 l6 offset-l3 xl6 offset-xl3">
            <div class="card-panel">
                <h4 class="center grey-text text-darken-1">Admin Login</h4>
                <form action="<?php echo e(route('admin.login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-field">
                        <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                        <label for="email">Email</label>
                        <?php if($errors->has('email')): ?>
                            <span class="helper-text red-text"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" id="password">
                        <label for="password">Password</label>
                        <?php if($errors->has('password')): ?>
                            <span class="helper-text red-text"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <p>
                        <label for="remember">
                            <input type="checkbox" name="remember" id="remember">
                            <span>Remember Me</span>
                        </label>
                    </p>
                    <div class="row"></div>
                    <button type="submit" class="btn mb-5 left">Login</button>
                    <a href="<?php echo e(route('admin.password.request')); ?>" class="btn right">Forgot Password</a>
                    <br><br><br>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>