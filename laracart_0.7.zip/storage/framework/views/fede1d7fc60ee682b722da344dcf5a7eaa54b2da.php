<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card-panel">
                    <h4 class="center grey-text text-darken-1">My Wishlist</h4>
                    <br>
                    <table class="responsive-table centered grey-text text-darken-3">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Available Stock</th>
                                <th>Price</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($wishlist->id); ?>">
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td>
                                        <img width="60px" height="50px" src="<?php echo e(asset('storage/products/'.$wishlist->product->image)); ?>" alt="">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('product-details',$wishlist->product->slug)); ?>"><?php echo e($wishlist->product->title); ?></a>
                                    </td>
                                    <td><?php echo e($wishlist->product->hasCategory->title); ?></td>
                                    <td class="val"><?php echo e($wishlist->product->quantity); ?></td>
                                    <td class="val">$<?php echo e(number_format($wishlist->product->price,2)); ?> /-</td>
                                    <td>
                                        <a href="#" class="btn-floating waves-effect waves-light btn-small add-cart" data-id="<?php echo e($wishlist->product->id); ?>">
                                            <i class="material-icons">add_shopping_cart</i>
                                        </a>
                                        <a href="#" class="btn-floating waves-effect waves-light btn-small red" onclick="this.preventDefault;document.querySelector('#delete-wishlist').submit()">
                                            <i class="material-icons">delete</i>
                                        </a>
                                        <form action="<?php echo e(route('wishlist.destroy',$wishlist->id)); ?>" method="post" class="hide" id="delete-wishlist">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br><br>
                    <div class="center-align">
                        <?php echo e($wishlists->links('vendor.pagination.default',['items' => $wishlists])); ?>

                    </div>
                    <br><br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>