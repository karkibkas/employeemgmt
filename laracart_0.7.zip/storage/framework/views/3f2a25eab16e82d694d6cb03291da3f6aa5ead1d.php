<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="card-panel col s12 m8 offset-m2 l6 offset-l3 xl6 offset-xl3">
            <h4 class="center grey-text text-darken-1">Register</h4>
            <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-field">
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    <label for="name">Name</label>
                    <?php if($errors->has('name')): ?>
                        <span class="helper-text red-text"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="input-field">
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    <label for="email">Email</label>
                    <?php if($errors->has('email')): ?>
                        <span class="helper-text red-text"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="input-field">
                    <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
                    <label for="password">Password</label>
                    <?php if($errors->has('password')): ?>
                        <span class="helper-text red-text"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="input-field">
                    <input type="password" name="password_confirmation" id="password-confirm" value="<?php echo e(old('password-confirm')); ?>">
                    <label for="password-confirm">Confirm Password</label>
                    <?php if($errors->has('password-confirm')): ?>
                        <span class="helper-text red-text"><?php echo e($errors->first('password-confirm')); ?></span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn col s12 m8 offset-m2 l6 offset-l3 xl6 offset-xl3">register</button>
                <br><br><br>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>