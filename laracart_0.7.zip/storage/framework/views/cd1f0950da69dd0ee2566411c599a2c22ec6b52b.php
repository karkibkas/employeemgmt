<nav class="nav-wrapper bg">
    <div class="container-fluid">
        <a href="<?php echo e(route('index')); ?>" class="brand-logo">LARACART</a>
        <ul class="show-on-med-and-small">
            <li class="waves-effect">
                <a href="#" data-target="sidenav" class="sidenav-trigger waves-effect"><i class="material-icons">menu</i></a>
            </li>
        </ul>
        <ul class="hide-on-med-and-down right">
            <li class="waves-effect">
                <a href="<?php echo e(route('index')); ?>">Home</a>
            </li>
            <li class="waves-effect">
                <a href="<?php echo e(route('products')); ?>">Products</a>
            </li>
            <li class="waves-effect">
                <a href="<?php echo e(route('about')); ?>">About</a>
            </li>
            <li class="waves-effect">
                <a href="<?php echo e(route('contact')); ?>">Contact</a>
            </li>
            <?php if(auth()->guard()->check()): ?>
                <li>
                    <a href="#" class="dropdown-trigger" data-target="user-dropdown">
                        <?php echo e(Auth::user()->name); ?>

                        <i class="material-icons right mt-3">arrow_drop_down</i>
                    </a>
                </li>
                <ul id='user-dropdown' class='dropdown-content'>
                    <li>
                        <a href="<?php echo e(route('profile')); ?>">Profile</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('order.index')); ?>">Order History</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('wishlist.index')); ?>">My Wishlist</a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        
                        <a href="#" onclick="this.preventDefault;document.querySelector('#user-logout').submit()">Logout</a>
                        <form action="<?php echo e(route('logout')); ?>" method="post" class="hide" id="user-logout">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            <?php else: ?>
                <li class="waves-effect">
                    <a href="<?php echo e(route('login')); ?>">Login</a>
                </li>
                <li class="waves-effect">
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                </li>
            <?php endif; ?>
            <li class="waves-effect">
                <a href="<?php echo e(route('cart.index')); ?>" class="val">
                    <i class="material-icons left cart-icon">shopping_cart</i>
                    <span class="cart-count">(<?php echo e(Cart::count()); ?>)</span>
                </a>
            </li>
        </ul>
    </div>
</nav>


<?php echo $__env->make('inc.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>