<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="card-panel grey-text text-darken-1">
            <ul class="collection with-header">
                <li class="collection-header">
                    <h4 class="center">Product Details</h4>
                </li>
                <li class="collection-item">
                    <h5 class="center"><?php echo e($product->title); ?></h5>
                </li>
                <li class="collection-item">
                    <div>
                        <img src="<?php echo e(asset('storage/products/'.$product->image)); ?>" width="100%" height="320px" alt="">
                    </div>
                </li>
                <li class="collection-item">
                    <h5 class="center">Product Description</h5>
                    <p><?php echo $product->description; ?></p>
                </li>
                <li class="collection-item">
                    <p>
                        <strong>Category: </strong>
                        <span><?php echo e($product->hasCategory->title); ?></span>
                    </p>
                    <p>
                        <strong>Price: </strong>
                        <span>$<?php echo e($product->price); ?></span>
                    </p>
                    <p>
                        <strong>Quantity: </strong>
                        <span><?php echo e($product->quantity); ?></span>
                    </p>
                </li>
                <li class="collection-item">
                    <div class="row">
                        <div class="col s12 m6 l6 xl6 row">
                            <a href="<?php echo e(route('admin.products.edit',$product->id)); ?>" class="btn orange waves-effect waves-light col s12">
                                <i class="material-icons left">update</i>
                                Update
                            </a>
                        </div>
                        <?php $__env->startComponent('components.confirm',[
                            'id'    => 'delete-form',
                            'modal' => 'deleteModal',
                            'title' => 'Product'
                        ]); ?>
                        <?php echo $__env->renderComponent(); ?>
                        <div class="col s12 m6 l6 xl6 row">
                            <a href="#deleteModal" class="btn red waves-effect waves-light col s12 modal-trigger">
                                <i class="material-icons left">delete</i>
                                Delete
                            </a>
                        </div>
                        <form action="<?php echo e(route('admin.products.destroy',$product->id)); ?>" method="post" class="hide" id="delete-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>