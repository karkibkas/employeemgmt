<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col s12 m12 l8 xl8">
            <div class="card-panel">
                <div class="row">
                    <form action="<?php echo e(route('checkout')); ?>" method="post" id="checkout-form">
                        <?php echo csrf_field(); ?>
                        <div class="col s12 m12 l12 xl12">
                            <br>
                            <h5 class="center grey-text text-darken-1" >Shipping Address</h5>
                            <br>
                            <div class="input-field">
                                <textarea name="address_1" id="address_1" class="materialize-textarea"></textarea>
                                <label for="address_1">Address line 1</label>
                                <?php if($errors->has('address_1')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('address_1')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field">
                                <textarea name="address_2" id="address_2" class="materialize-textarea"></textarea>
                                <label for="address_2">Address Line 2</label>
                                <?php if($errors->has('address_2')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('address_2')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field">
                                <input type="text" name="city" id="city">
                                <label for="city">City</label>
                                <?php if($errors->has('city')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('city')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field">
                                <input type="text" name="postal_code" id="postal_code">
                                <label for="postal_code">Postal code</label>
                                <?php if($errors->has('postal_code')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('postal_code')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field">
                                <div id="dropin-container"></div>
                                <button id="check-out-btn" class="btn center">Request Payment Method</button>
                            </div>
                            <input type="hidden" name="nonce" id="nonce">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col s12 m12 l4 xl4">
            <div class="card-panel">
                <?php $__env->startComponent('components.cart-summary'); ?>
                <?php echo $__env->renderComponent(); ?>
                <br>
                <a href="#" class="btn waves-effect waves-light" onclick="this.preventDefault;document.querySelector('#checkout-form').submit()">Place Order</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://js.braintreegateway.com/web/dropin/1.11.0/js/dropin.min.js"></script>

    <script>
        var button = document.querySelector('#check-out-btn');
        // Get the braintree token from server
        // and init the dropin-ui 
        $(document).ready(function(){
            $.ajax({
                url: '/braintree/token',
                type:'GET',
                dataType:'json',
                success: function(data){
                    braintree.dropin.create({
                    authorization: data.token,
                    container: '#dropin-container'
                    }, function (createErr, instance) {
                    button.addEventListener('click', function (e) {
                        e.preventDefault();
                        instance.requestPaymentMethod(function (requestPaymentMethodErr, payload) {
                        // Submit payload.nonce to your server
                        $('#nonce').val(payload.nonce);
                        });
                    });
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>