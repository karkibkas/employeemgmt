<?php $__env->startSection('content'); ?>
<h3 class="center grey-text text-darken-1">About Page</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>