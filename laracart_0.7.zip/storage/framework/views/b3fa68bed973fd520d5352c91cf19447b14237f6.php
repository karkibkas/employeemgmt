<?php $__env->startSection('content'); ?>
<div class="container">
    <br><br>
    <div class="card-panel">
        <h4 class="center">Reset Password</h4>
        <form method="POST" action="<?php echo e(route('admin.password.request')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="input-field">
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
                <label for="email">Email</label>
                <?php if($errors->has('email')): ?>
                    <span class="helper-text red-text"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="input-field">
                <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
                <label for="password">Password</label>
                <?php if($errors->has('password')): ?>
                    <span class="helper-text red-text"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
            <div class="input-field">
                <input type="password" name="password_confirmation" id="password-confirm" value="<?php echo e(old('password-confirm')); ?>">
                <label for="password-confirm">Confirm Password</label>
                <?php if($errors->has('password-confirm')): ?>
                    <span class="helper-text red-text"><?php echo e($errors->first('password-confirm')); ?></span>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn col s12 m8 offset-m2 l6 offset-l3 xl6 offset-xl3">Reset Password</button>
            <br><br><br>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>