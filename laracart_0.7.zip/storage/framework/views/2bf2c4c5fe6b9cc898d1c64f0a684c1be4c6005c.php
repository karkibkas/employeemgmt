<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col s12 m12 xl8">
            <div class="card-panel cart-panel">
                <?php if(!Cart::count()): ?>
                    <h5 class="grey-text text-darken-2 center">Your cart is empty! <a href="<?php echo e(route('products')); ?>"> Start Shopping</a></h5>
                <?php else: ?>
                    <table class="responsive-table cart-items">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($product->id); ?>">
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td>
                                        <div>
                                            <img src="<?php echo e(('storage/products/'.App\Product::where('slug' , $product->id)->first()->image)); ?>" width="50px"  height="50px"  alt="">
                                        </div>
                                    </td>
                                    <td>
                                        
                                        <?php if(!App\Product::where('slug' , $product->id)->first()->hasStock($product->qty)): ?>
                                            <a class="tooltipped red-text" data-position="bottom" data-tooltip="This item has insufficient stock!" href="<?php echo e(route('product-details',$product->id)); ?>"><?php echo e($product->name); ?></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('product-details',$product->id)); ?>"><?php echo e($product->name); ?></a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="val">$<?php echo e($product->price); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('cart.index')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="row"  style="margin-bottom:0 !important">
                                                <input type="hidden" id="rowId-<?php echo e($product->id); ?>" value="<?php echo e($product->rowId); ?>">
                                                <div class="input-field col s9 xl5">
                                                    <select name="qty" id="qty-<?php echo e($product->id); ?>">
                                                        <option value="0">None</option>
                                                        <?php for($i = 0; $i < App\Product::where('slug' , $product->id)->first()->quantity; $i++): ?>
                                                            <option value="<?php echo e($i+1); ?>" <?php echo e($product->qty == ($i+1) ? 'selected' : ''); ?>><?php echo e($i + 1); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                    <label>Quantity</label>
                                                </div>
                                                <div class="col">
                                                <br>
                                                <button type="submit" data-id="<?php echo e($product->id); ?>" class="btn-floating waves-effect bg2 tooltipped update-cart" data-position="bottom" data-tooltip="Update quantity">
                                                    <i class="material-icons">sync</i>
                                                </button>
                                                </div>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>        
                <?php endif; ?>
            </div>
            <br><br>
        </div>
        <div class="col s12 m12 xl4">
            <div class="card-panel">
                <?php $__env->startComponent('components.cart-summary'); ?>
                <?php echo $__env->renderComponent(); ?>
                <br>
                <a class="btn waves-effect waves-light green lighten-1 checkout-btn <?php echo e(!Cart::count() ? 'disabled': ''); ?>" href="<?php echo e(route('checkout')); ?>">check out</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>