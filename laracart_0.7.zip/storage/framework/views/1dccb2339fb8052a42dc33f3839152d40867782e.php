<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="card-panel">
            <br>
            <h4 class="center grey-text text-darken-1">Products List</h4>
            <br>
            <table class="responsive-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Created at</th>
                        <th>Updated at</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td>
                                <img width="50px" height="50px" src="<?php echo e(asset('storage/products/'.$product->image)); ?>" alt="">
                            </td>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->title); ?></td>
                            <td><?php echo e($product->hasCategory->title); ?></td>
                            <td class="center"><?php echo e($product->quantity); ?></td>
                            <td><?php echo e($product->created_at->diffForHumans()); ?></td>
                            <?php if($product->updated_at): ?>
                                <td><?php echo e($product->updated_at->diffForHumans()); ?></td>
                            <?php else: ?>
                                <td>Not updated</td>
                            <?php endif; ?>
                            <td>
                                <div class="center">
                                    <a href="<?php echo e(route('admin.products.show',$product->id)); ?>" class="btn-floating btn-small waves-effect waves-light tooltipped" data-position="left" data-tooltip="Show Product Details">
                                        <i class="material-icons">description</i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <br><br>
            <div class="center-align">
                <?php echo e($products->links('vendor.pagination.default',[ 'items' => $products ])); ?>

            </div>
        </div>
    </div>
    <div class="fixed-action-btn">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn-floating btn-large waves-effect waves-light red">
            <i class="large material-icons">add</i>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>