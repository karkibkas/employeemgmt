<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col s12 m10 offset-m1 l8 offset-l2 xl6 offset-xl3">
            <div class="card-panel">
                <h4 class="center grey-text text-darken-1">My Profile</h4>
                <br>
                <div class="center-align">
                    <img src="<?php echo e(Auth::user()->gravatar); ?>" alt="<?php echo e(Auth::user()->name); ?>">
                </div>
                <br>
                <form action="<?php echo e(route('profile')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="input-field col s12">
                            <input type="text" name="name" id="name" class="grey-text text-darken-4" value="<?php echo e(old('name') ? : Auth::user()->name); ?>">
                            <label for="name" class="active">Name</label>
                            <?php if($errors->has('name')): ?>
                                <span class="red-text helper-text">
                                    <?php echo e($errors->first('name')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-field col s12">
                            <input type="email" name="email" id="email" class="grey-text text-darken-4" value="<?php echo e(old('email') ? : Auth::user()->email); ?>">
                            <label for="email" class="active">Email</label>
                            <?php if($errors->has('email')): ?>
                                <span class="red-text helper-text">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="input-field col s12">
                            <input type="password" name="password" id="password" class="grey-text text-darken-4">
                            <label for="password" class="active">Password</label>
                        </div>
                        <div class="row"></div>
                        <button type="submit" class="btn waves-effect waves-light bg2 col s12 m6 offset-m3 l6 offset-l3 xl6 offset-xl3">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>