<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <?php if(auth::guard('admin')->check()): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <?php endif; ?>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Laracart | The Best Online Store Like Ever...</title>
</head>
<body>
    
        

    
    <header>

        <?php if(Auth::guard('admin')->check()): ?>
            
            <?php echo $__env->make('admin.inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            
            <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </header>

    <main>
        <br><br><br>
        
        <?php echo $__env->yieldContent('content'); ?>
        <br><br><br>
    </main>

    
    <?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    
    <?php echo $__env->make('inc.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>