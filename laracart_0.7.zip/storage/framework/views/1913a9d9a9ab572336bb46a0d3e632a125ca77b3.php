<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="card-panel">
                <br>
                <h4 class="center grey-text text-darken-1">New Product</h4>
                <div>
                    <form action="<?php echo e(route('admin.products.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="input-field col s12 m10 offset-m1 l6 xl6">
                                <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>">
                                <label for="title">Name</label>
                                <?php if($errors->has('title')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('title')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12 m10 offset-m1 l6 xl6">
                                <select name="category">
                                <option value="" disabled selected>Choose a Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e((old('category') == ($category->id)) ? 'selected' : ''); ?>><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label>Product Category:</label>
                                <?php if($errors->has('category')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('category')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12 m10 offset-m1 l12 xl12">
                                <textarea name="description" id="description" class="materialize-textarea"><?php echo e(old('description')); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('description')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12 m5 offset-m1 l6 xl6">
                                <input type="number" name="quantity" id="quantity"  value="<?php echo e(old('quantity')); ?>">
                                <label for="quantity">Quantity</label>
                                <?php if($errors->has('quantity')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('quantity')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12 m5 l6 xl6">
                                <input type="number" name="price" id="price" value="<?php echo e(old('price')); ?>">
                                <label for="price">Price</label>
                                <?php if($errors->has('price')): ?>
                                    <span class="helper-text red-text">
                                        <?php echo e($errors->first('price')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="file-field input-field col s12 m10 offset-m1 l12 xl12">
                                <div class="btn waves-effect waves-light bg2">
                                    <span>Picture</span>
                                    <input type="file" name="image">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text" value="<?php echo e(old('image')); ?>">
                                    <?php if($errors->has('image')): ?>
                                        <span class="helper-text red-text">
                                            <?php echo e($errors->has('image') ? $errors->first('image') : ''); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row"></div>
                            <button type="submit" class="btn waves-effect waves-light bg col s12 m8 offset-m2 l4 offset-l4 xl4 offset-xl4">Create Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'description' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>